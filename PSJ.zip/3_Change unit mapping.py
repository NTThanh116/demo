#Change UNIT from CFD mapping result
# OUT_Temp = IN_TEMP - 273.15
# OUT_HTC = IN_HTC/1000^2
## Witer: Ikeda

import os
from pyjdg import *
from tkinter import Tk, filedialog

def process_file(input_file):
    # Tạo file output trong cùng thư mục với input_file với tiền tố "_HEAT_film_"
    folder = os.path.dirname(input_file)
    filename = os.path.basename(input_file)
    output_file = os.path.join(folder, f"_HEAT_film_{filename}")

    with open(input_file, "r", encoding="utf-8") as f:
        lines = f.readlines()

    new_lines = []
    inside_film = False

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("*FILM"):
            inside_film = True
            new_lines.append(line)
            continue
        if inside_film and stripped.startswith("*") and not stripped.startswith("*FILM"):
            inside_film = False

        if inside_film and not stripped.startswith("*"):
            parts = stripped.split(",")
            if len(parts) >= 4:
                try:
                    # Chuyển đổi đơn vị: TEMP từ Kelvin sang Celsius, HTC chia cho 1,000,000
                    val3 = float(parts[2]) - 273.15
                    val4 = float(parts[3]) / 1_000_000
                    parts[2] = f"{val3:.10g}"
                    parts[3] = f"{val4:.10g}"
                    line = ",".join(parts) + "\n"
                except ValueError:
                    pass
        new_lines.append(line)

    with open(output_file, "w", encoding="utf-8") as f:
        f.writelines(new_lines)

def process_files(input_files):
    for file in input_files:
        process_file(file)

def onGetButton1Clicked(dlg):
    input_files = dlg.get_item_text(name="change_unit")
    # Nếu người dùng chọn nhiều file thì giá trị trả về sẽ là danh sách
    # Nếu là chuỗi, ta kiểm tra xem có chứa dấu phân cách không
    if isinstance(input_files, str):
        if ";" in input_files:
            input_files = [s.strip() for s in input_files.split(";") if s.strip()]
        else:
            input_files = [input_files]
    process_files(input_files)
    JPT.MessageBoxPSJ("Export successful", JPT.MsgBoxType.MB_INFORMATION_YESNOCANCEL)

def main():
    dlg = JDGCreator(title="Change unit mapping", include_apply=False)

    dlg.add_groupbox(name="GroupBox1", text="INPUT FILES", layout="Window")
    dlg.add_label(name="Label", text="Select mapping file(s):", layout="GroupBox1")
    # Sử dụng thứ tự tham số: layout, name, mode, file_filter, default, multisel
    dlg.add_browser("GroupBox1", "change_unit", "file", "All Files(*.*)", "", 1)

    dlg.add_layout(name="Layout1.2", margin=[200, 0, 0, 0], 
                   orientation=orientation.horizontal, layout="GroupBox1")
    dlg.add_button(name="Button1", text="Previews", width=60, height=22, 
                   bk_color=15790320, layout="Layout1.2")
    
    dlg.generate_window()
    dlg.on_dlg_ok(callfunc=onGetButton1Clicked)

if __name__=='__main__':
    main()

